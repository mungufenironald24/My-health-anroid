# My Health Android project (v0.3.0)

This is an Android Studio project wrapping the current My Health web prototype in a native Android WebView. It is a project source package, **not yet a compiled APK**.

## Build an APK
1. Install Android Studio on a computer and ensure Android SDK Platform 35 and a compatible JDK are installed.
2. Open this `MyHealthAndroid` folder in Android Studio.
3. Allow Gradle sync and install any requested SDK components.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the location of the debug APK (usually `app/build/outputs/apk/debug/app-debug.apk`).

For a command-line build, run `gradle assembleDebug` from this directory in an environment with Android SDK configured and Gradle installed.

## Included
- Android launcher activity named My Health
- WebView that loads the current prototype from bundled assets
- Internet permission for online map searches
- Symptom safety guide, health topics, medicine safety information, maternal/child health, emergency guide and facility map search from the included prototype

## Safety and release status
This is a prototype for testing, not a clinically validated medical device. Symptom advice is educational and must not be treated as a diagnosis or prescription. Clinical content requires review by qualified Ugandan health professionals against current Ministry of Health guidance before public release. Test emergency wording, accessibility, offline behavior and WebView compatibility before distribution. No signing key is included; create and safeguard your own release signing key if publishing.
