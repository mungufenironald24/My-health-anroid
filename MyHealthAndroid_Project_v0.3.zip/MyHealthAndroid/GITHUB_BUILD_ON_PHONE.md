# Build My Health APK from an Android phone using GitHub Actions

This is an experimental debug build workflow. It creates an unsigned-for-release debug APK for testing; it is not a production release.

## Easiest phone workflow
1. Create a new GitHub repository, for example `my-health-android`. Public or private is your choice.
2. Upload the file `MyHealthAndroid_Project_v0.3.zip` to the repository root (do not extract it on your phone).
3. Create a new file in the repository at `.github/workflows/build-apk.yml`.
4. Copy the workflow from the provided `build-apk.yml` file into that new file and commit it.
5. Important: the workflow expects the uploaded zip to be named exactly `MyHealthAndroid_Project_v0.3.zip` and to contain a top-level `MyHealthAndroid/` directory. The workflow must unzip it before building. Use the workflow version below that includes the unzip step.
6. Open the repository's **Actions** tab, select **Build My Health APK**, then tap **Run workflow** if it has not started automatically.
7. When it finishes successfully, open the workflow run and download the `MyHealth-debug-APK` artifact. GitHub may download it as a ZIP; extract it in your phone's Files app to find `app-debug.apk`.
8. Tap the APK to install. Android may ask you to allow your browser or file manager to install unknown apps. Only install APKs you built and trust.

## Workflow note
Because uploading the project as one ZIP keeps folder structure simple on a phone, add this unzip step before the Gradle build step:

```yaml
      - name: Unpack Android project ZIP
        run: unzip -q MyHealthAndroid_Project_v0.3.zip
```

The final build command should be:

```yaml
      - name: Build debug APK
        run: gradle -p MyHealthAndroid assembleDebug
```

Clinical content is a prototype and must be reviewed by qualified clinicians before public release. A debug APK is for testing only; it is not a signed production release.
